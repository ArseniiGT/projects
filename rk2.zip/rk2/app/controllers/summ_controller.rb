class SummController < ApplicationController
  def input; end

  def output
    a = params[:val].split.map(&:to_i)
    @source = a.join(' ')
    summ = 0
    index = a.find_index(&:even?)
    if index.nil?
      @result = 'Четных чисел не найдено'
    else
      a.each { |value| summ += value if value % 15 == 0 }
      @result = summ
      a[index] = summ
    end
    @arr = a.join(' ')
  end
end
