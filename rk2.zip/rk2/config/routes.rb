Rails.application.routes.draw do
  get 'summ/input'

  get 'summ/output'

  root 'summ#input'
end
