module PalindromeHelper
end
