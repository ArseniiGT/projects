# app/models/palindrome.rb

class Palindrome < ApplicationRecord
end
