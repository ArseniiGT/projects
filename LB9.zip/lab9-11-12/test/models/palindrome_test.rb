require 'test_helper'

class PalindromeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
