require 'test_helper'
require 'selenium-webdriver'

class PalindromeControllerTest < ActionDispatch::IntegrationTest
  #  test 'Нормальные данные' do
  #   get palindrome_input_url(:value => 654)
  #   assert[:result]
  # end
end
